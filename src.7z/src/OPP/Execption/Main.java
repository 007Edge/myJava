package OPP.Execption;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
            int n = sc.nextInt();
            System.out.println(1 / 0);
        } catch (InputMismatchException e) {
            System.out.println("That wasn't a number!");
        } catch (ArithmeticException e) {
            System.out.println("You can't divide it by zero !");
        } catch (Exception e) {
            System.out.println("Something went wrong");
        } finally {    // this always execute no matter exception occurred or not.
            // not necessary to close in case of System.in
            System.out.println("This always execute");
            // in case we are dealing with any server network we need to close Scanner explicitly
        }
    }
}
