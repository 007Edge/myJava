package OPP.Interfaces;

public interface Break {
    void stopCar();

}
