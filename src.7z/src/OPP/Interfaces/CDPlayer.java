package OPP.Interfaces;

public class CDPlayer implements Music{
    public void start() {
        System.out.println("Music Starts");
    }
    public void stop() {
        System.out.println("Music Stops");
    }
}
