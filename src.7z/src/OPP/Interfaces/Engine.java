package OPP.Interfaces;

public interface Engine {
    void start();
    void stop();
    void acc();

}
