package OPP.Interfaces;

public interface Music {
    void start();
    void stop();
}
