package OPP.Interfaces.NestedInterface;

public class Main {
    public static void main(String[] args) {
        B obj = new B();
        obj.printHello();
    }
}
