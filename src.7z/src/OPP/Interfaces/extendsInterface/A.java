package OPP.Interfaces.extendsInterface;

public interface A {
    default void banana() {
        System.out.println("I am in b");
    }
}

