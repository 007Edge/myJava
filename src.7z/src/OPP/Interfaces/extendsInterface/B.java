package OPP.Interfaces.extendsInterface;

public interface B extends A {
    void apple();
}
