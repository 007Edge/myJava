package OPP.inheritance;

public class Monkey extends Animal{

    String name;

    Monkey(String name) {
        super(name);
        this.name = name;
    }
}
